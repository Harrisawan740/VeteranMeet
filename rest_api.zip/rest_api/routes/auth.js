const router = require("express").Router();
const user= require("../models/user");
const bcrypt = require("bcrypt");
//signup
//get
// router.get("/signup", async (req,res)=>{
//     const User= await new user({
        
//     })


//     await User.save();
//     res.send("ok");
// });

//signup
router.post("/signup", async (req,res)=>{
  

  try{
    //new password
    const salt= await bcrypt.genSalt(10);
    const hashPassword= await bcrypt.hash(req.body.password, salt);


    //new user
    const newUser= new user({
        username:req.body.username,
        email:req.body.email,
        password:hashPassword,
      });


      //saving user
    const User= await newUser.save();
    res.status(200).json(User);
  } catch(err){
    res.status(500).json(err)
  }
});


//login
router.post("/login", async (req,res)=>{
    try{
    const User= await  user.findOne({email:req.body.email});
    !User && res.status(404).json("invalid user");

    const validPassword =await bcrypt.compare(req.body.password, User.password)
    !validPassword && res.status(400).json("incorrect password")

    res.status(200).json(User);
    }catch(err){
        res.status(500).json(err)
    }
});


module.exports  = router;