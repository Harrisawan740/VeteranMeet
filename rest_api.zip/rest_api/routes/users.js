const user= require("../models/user");
const router = require("express").Router();
const bcrypt= require ("bcrypt");
const { json } = require("express");


//delete user
router.delete("/:id", async(req,res)=>{
    if(req.body.userId === req.params.id || req.body.isAdmin){
        
        try{
            await user.findByIdAndDelete(req.params.id);
                res.status(200).json("deleted successfully")
        }catch(err){
            return res.status(500).json(err);
        }
    }else{
        return res.status(403).json("you cant delete someone else's account");
    }
});

//update user info
router.put("/:id", async(req,res)=>{
    if(req.body.userId === req.params.id || req.body.isAdmin){
        if(req.body.password){
            try{
                const salt= await bcrypt.genSalt(10);
                req.body.password= await  bcrypt.hash(req.body.password, salt);

            }catch(err){
                return res.status(500).json(err);
            }
        }
        try{
            const User= await user.findByIdAndUpdate(req.params.id,
                 {$set:req.body,
                });
                res.status(200).json("updated")
        }catch(err){
            return res.status(500).json(err);
        }
    }else{
        return res.status(403).json("you cant update someone else's account");
    }
});


//get one user
router.get("/:id",async(req,res)=>{
    try{
        const User= await user.findById(req.params.id);
        const {password, updatedAt, ...other}= User._doc
        res.status(200).json(other);
    }catch(err){
        res.status(500).json(err)
    }
})

//follow
router.put("/:id/follow", async(req,res)=>{
    if(req.body.userId !== req.params.id ){
        try{
            const User= await user.findById(req.params.id);
            const currentUser=  await user.findById(req.body.userId);
            if(!User.followers.includes(req.body.userId)){
                await User.updateOne({$push:{followers: req.body.userId}});
                await currentUser.updateOne({$push:{followings:req.params.id}});
                res.status(200).json("you just followed the user");
            }else{
                res.status(403).json("you are already a follower");
            }
                
        }catch(err){
            res.status(500).json(err);
        }
    }else{
        res.status(403).json("you cant follow your own self");
    }
});

//unfollow
router.put("/:id/unfollow", async(req,res)=>{
    if(req.body.userId !== req.params.id ){
        try{
            const User= await user.findById(req.params.id);
            const currentUser=  await user.findById(req.body.userId);
            if(User.followers.includes(req.body.userId)){
                await User.updateOne({$pull:{followers: req.body.userId}});
                await currentUser.updateOne({$pull:{followings:req.params.id}});
                res.status(200).json("you just unfollowed the user");
            }else{
                res.status(403).json("you are not a follower");
            }
                
        }catch(err){
            res.status(500).json(err);
        }
    }else{
        res.status(403).json("you cant unfollow your own self");
    }
});


module.exports  = router;