export const TrendData= [
  {
    name: "NASCON",
    shares: 99,
  },
  {
    name: "Adventure Gala",
    shares: 79.5,
  },
  {
    name: "PPIT Seminar",
    shares: 73.5,
  },
  {
    name: "FYT",
    shares: 71.8,
  },
];
